// Registered persistently only while cosmetic filtering is enabled.
(() => {
  const enable = () => document.documentElement?.setAttribute('data-dzen-clean-early', 'on');
  if (document.documentElement) enable();
  else { const o = new MutationObserver(() => {if (document.documentElement) {enable(); o.disconnect();}}); o.observe(document, {childList: true}); }
})();
