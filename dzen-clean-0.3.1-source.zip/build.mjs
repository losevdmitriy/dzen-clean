import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash, createPrivateKey, createPublicKey, generateKeyPairSync, sign, verify} from 'node:crypto';
import {deflateRawSync} from 'node:zlib';

const root = path.dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2);
function argument(name) {
  const index = args.indexOf(name);
  if (index < 0 || !args[index + 1]) throw new Error(`Required argument: ${name} <path>`);
  return path.resolve(args[index + 1]);
}
const keyPath = argument('--key');
const out = argument('--out');
// Keep the signing key outside both the extension directory and packaged files.
if (keyPath === root || keyPath.startsWith(root + path.sep)) throw new Error('Keep the private key outside the extension folder');
fs.mkdirSync(out, {recursive: true});
fs.mkdirSync(path.dirname(keyPath), {recursive: true});
if (!fs.existsSync(keyPath)) {
  const pair = generateKeyPairSync('ec', {namedCurve: 'prime256v1'});
  fs.writeFileSync(keyPath, pair.privateKey.export({type: 'pkcs8', format: 'pem'}), {flag: 'wx', mode: 0o600});
}
const key = createPrivateKey(fs.readFileSync(keyPath));
if (key.asymmetricKeyType !== 'ec' || key.asymmetricKeyDetails.namedCurve !== 'prime256v1') throw new Error('Expected ECDSA P-256 private key');
const pub = createPublicKey(key).export({type: 'spki', format: 'der'});
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'manifest.json'), 'utf8'));
const allowedDirectories=new Set(['icons','rules','resources','experimental','vendor','src','tools','tests','licenses','data','engine-filters','web-accessible-resources','third-party']);
const allowedRoot=new Set(['LICENSE','manifest.json','settings.js','filters.js','background.js','background.js.LEGAL.txt','general.js','general.js.LEGAL.txt','content.js','updater.js','early.js','early.css','popup.html','popup.css','popup.js','README.md','PRIVACY.md','REFERENCES.md','VALIDATION.md','THIRD_PARTY.md','MANUAL_TESTS.md','build.mjs','package.json','pnpm-lock.yaml','pnpm-workspace.yaml']);
function collect(folder, prefix='') {
  const files=[];
  for(const entry of fs.readdirSync(folder,{withFileTypes:true})) {
    if(entry.isSymbolicLink())continue;
    const relative=prefix+entry.name;
    if(entry.isDirectory()) {if(prefix || allowedDirectories.has(entry.name))files.push(...collect(path.join(folder,entry.name),relative+'/'));}
    else if((prefix || allowedRoot.has(entry.name)) && !/\.(pem|key)$/i.test(entry.name))files.push(relative);
  }
  return files.sort();
}
const files=collect(root);
const crcTable = Array.from({length: 256}, (_, n) => {
  for (let i = 0; i < 8; i++) n = n & 1 ? 0xedb88320 ^ (n >>> 1) : n >>> 1;
  return n >>> 0;
});
function crc32(buffer) {
  let value = 0xffffffff;
  for (const byte of buffer) value = crcTable[(value ^ byte) & 255] ^ (value >>> 8);
  return (value ^ 0xffffffff) >>> 0;
}
function u32(n) { const result = Buffer.alloc(4); result.writeUInt32LE(n); return result; }
// Deterministic DEFLATE ZIP, UTF-8 names, DOS epoch. Excludes caches and keys.
const local = [], central = [];
let offset = 0;
for (const filename of files) {
  const name = Buffer.from(filename);
  const data = fs.readFileSync(path.join(root, filename));
  const compressed=deflateRawSync(data,{level:9});
  const crc = crc32(data);
  const header = Buffer.alloc(30);
  header.writeUInt32LE(0x04034b50, 0); header.writeUInt16LE(20, 4); header.writeUInt16LE(0x800, 6);
  header.writeUInt16LE(8,8);
  header.writeUInt16LE(33, 12); header.writeUInt32LE(crc, 14);
  header.writeUInt32LE(compressed.length, 18); header.writeUInt32LE(data.length, 22); header.writeUInt16LE(name.length, 26);
  local.push(header, name, compressed);
  const directory = Buffer.alloc(46);
  directory.writeUInt32LE(0x02014b50, 0); directory.writeUInt16LE(20, 4); directory.writeUInt16LE(20, 6);
  directory.writeUInt16LE(0x800, 8); directory.writeUInt16LE(33, 14); directory.writeUInt32LE(crc, 16);
  directory.writeUInt16LE(8,10);
  directory.writeUInt32LE(compressed.length, 20); directory.writeUInt32LE(data.length, 24);
  directory.writeUInt16LE(name.length, 28); directory.writeUInt32LE(offset, 42);
  central.push(directory, name);
  offset += header.length + name.length + compressed.length;
}
const directory = Buffer.concat(central);
const end = Buffer.alloc(22);
end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(files.length, 8); end.writeUInt16LE(files.length, 10);
end.writeUInt32LE(directory.length, 12); end.writeUInt32LE(offset, 16);
const zip = Buffer.concat([...local, directory, end]);
function varint(value) {
  const bytes = [];
  do { const next = value & 127; value >>>= 7; bytes.push(next | (value ? 128 : 0)); } while (value);
  return Buffer.from(bytes);
}
function field(number, value) { return Buffer.concat([varint((number << 3) | 2), varint(value.length), value]); }
const crxId = createHash('sha256').update(pub).digest().subarray(0, 16);
const signedHeader = field(1, crxId);
const signedBytes = Buffer.concat([Buffer.from('CRX3 SignedData\0'), u32(signedHeader.length), signedHeader, zip]);
const signature = sign('sha256', signedBytes, key);
if (!verify('sha256', signedBytes, createPublicKey(key), signature)) throw new Error('Signature verification failed');
const proof = Buffer.concat([field(1, pub), field(2, signature)]);
const header = Buffer.concat([field(3, proof), field(10000, signedHeader)]);
const crx = Buffer.concat([Buffer.from('Cr24'), u32(3), u32(header.length), header, zip]);
const basename = `dzen-clean-${manifest.version}`;
fs.writeFileSync(path.join(out, basename + '.zip'), zip);
fs.writeFileSync(path.join(out, basename + '.crx'), crx);
const hashes = [['zip', zip], ['crx', crx]].map(([ext, buffer]) => `${createHash('sha256').update(buffer).digest('hex')}  ${basename}.${ext}`).join('\n') + '\n';
fs.writeFileSync(path.join(out, basename + '.sha256'), hashes);
console.log(`Built ${basename}.zip and ${basename}.crx`);
console.log(`CRX ID: ${[...crxId].map(n => String.fromCharCode(97 + (n >> 4), 97 + (n & 15))).join('')}`);
