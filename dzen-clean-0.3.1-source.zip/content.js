(() => {
  'use strict';
  if (globalThis.__dzenClean02) return;
  const api = DzenClean, MARK = 'data-dzen-clean-ad', RESTORE = 'data-dzen-clean-restore';
  const CSS_TEXT = `[${MARK}="collapse"]{display:none!important}[${MARK}="preserve"]{visibility:hidden!important;pointer-events:none!important;block-size:0!important;min-block-size:0!important;max-block-size:0!important;overflow:hidden!important}`;
  let settings = {...api.defaults, enabled:false}, remote = [], remoteExceptions = [], combined = api.slots.join(','), timer, iterator, discoverIterator;
  let counter = 0, revision = 0, lastPath = location.pathname, configured = false;
  const roots = new Set([document]), styles = new Map(), records = new Map(), restored = new Set(), players = new Map();
  const pending = new Set(), ownWrites = new Map(), lastClick = new WeakMap(), iframeListeners = new WeakSet();
  const metrics = {scanned:0, batches:0, maxBatchMs:0, clicks:0, closed:0, invalidSelectors:0, shadowRoots:0,buttonChecks:0};
  const moduleStates = {};
  const shadow = el => {try{return chrome.dom?.openOrClosedShadowRoot?.(el) || el.shadowRoot;}catch{return el.shadowRoot;}};
  const parent = el => el.parentElement || el.getRootNode()?.host || null;
  function composedClosest(el, selector) {for (let n = el; n; n = parent(n)) if (n.matches?.(selector)) return n; return null;}
  function contains(root, node) {for (let n=node; n; n=parent(n)) if (n===root) return true; return false;}
  function own(el, attr, fn) {
    fn(); let map=ownWrites.get(el); if (!map) ownWrites.set(el,map=new Map()); map.set(attr,el.getAttribute(attr));
  }
  function visible(el) {
    const rect = el.getBoundingClientRect();
    if (!rect.width || !rect.height || composedClosest(el,'[hidden], [aria-hidden="true"]')) return false;
    for (let n=el;n;n=parent(n)) {const s=getComputedStyle(n); if (s.display==='none' || s.visibility!=='visible' || Number(s.opacity)===0) return false;}
    return true;
  }
  function protectedElement(el) {
    if (el===document.body || el===document.documentElement || el.matches(api.protectedContent) ||
        el.querySelector(api.protectedContent) || composedClosest(el,api.protectedArea)) return true;
    const sr=shadow(el);
    return !!sr?.querySelector(api.protectedContent);
  }
  function excepted(el) {
    if (composedClosest(el,`[${RESTORE}]`)) return true;
    if([...restored].some(node=>contains(el,node)))return true;
    return remoteExceptions.some(rule => {try{return el.matches(rule.selector) || !!el.querySelector(rule.selector);}catch{return false;}});
  }
  function unhide(el) {
    const record=records.get(el);
    if (!record) return;
    own(el,MARK,()=>el.removeAttribute(MARK));
    own(el,'style',() => {
      for (const [name,prop] of Object.entries(record.props)) if (el.style.getPropertyValue(name)===prop.value && el.style.getPropertyPriority(name)==='important') {
        if (prop.original) el.style.setProperty(name,prop.original,prop.priority); else el.style.removeProperty(name);
      }
    });
    records.delete(el);
  }
  function hide(el, reason) {
    if (!settings.enabled || !settings.cosmetic || records.has(el) || excepted(el) || protectedElement(el)) return;
    if (composedClosest(parent(el),`[${MARK}]`)) return;
    // A remotely maintained broad selector must not erase ordinary feed cards.
    if(reason.startsWith('filter:') && el.querySelector('a[href^="/a/"],a[href*="dzen.ru/a/"],a[href*="/video/watch/"]')) {
      const labelled=[...el.querySelectorAll('span,small')].some(n=>!n.childElementCount && api.label(n.textContent));
      const evidence=[...el.querySelectorAll('a[href]')].some(a=>api.adLink(a.href)) || el.hasAttribute('data-ad-type');
      if(settings.profile!=='experimental' || !labelled || !evidence)return;
    }
    const mode = /right-ad|right-ads|rightAd|advert-column|ad-column|top-sidebar-desktop-ad/i.test(`${el.className || ''} ${el.getAttribute('data-testid') || ''}`) || composedClosest(el,'aside') ? 'preserve' : 'collapse';
    const values = mode==='preserve' ? {visibility:'hidden','pointer-events':'none','block-size':'0px','min-block-size':'0px','max-block-size':'0px',overflow:'hidden'} : {display:'none'};
    const props={};
    for (const [name,value] of Object.entries(values)) props[name]={original:el.style.getPropertyValue(name),priority:el.style.getPropertyPriority(name),value};
    records.set(el,{id:`b${++counter}`, reason, mode, props});
    own(el,MARK,()=>el.setAttribute(MARK,mode));
    own(el,'style',()=>{for(const [name,value] of Object.entries(values)) el.style.setProperty(name,value,'important');});
  }
  function ensureStyle(root) {
    let style=styles.get(root);
    if (!style) {style=document.createElement('style');style.setAttribute('data-dzen-clean-style','');style.textContent=CSS_TEXT;styles.set(root,style);}
    if (!style.isConnected) (root===document ? document.head || document.documentElement : root)?.append(style);
  }
  function rootAdded(root) {
    if (roots.has(root)) return;
    roots.add(root); metrics.shadowRoots++;
    observer.observe(root,observation); if(settings.cosmetic)ensureStyle(root); schedule(root);
  }
  function selectorPath(el) {
    const root=el.getRootNode(), parts=[];
    for(let n=el;n?.nodeType===1;n=n.parentElement) {
      if (n.id && root.querySelectorAll('#'+CSS.escape(n.id)).length===1) {parts.unshift('#'+CSS.escape(n.id));break;}
      const siblings=n.parentElement ? [...n.parentElement.children].filter(x=>x.localName===n.localName) : [n];
      parts.unshift(n.localName+(siblings.length>1 ? `:nth-of-type(${siblings.indexOf(n)+1})` : ''));
      if(parts.length>15) throw new Error('Слишком глубокий контейнер. Добавьте исключение селектором.');
    }
    return parts.join(' > ');
  }
  function exceptionFor(el) {
    const hosts=[];
    for(let root=el.getRootNode();root.host;root=root.host.getRootNode()) hosts.unshift(selectorPath(root.host));
    return {id:crypto.randomUUID(),hostname:location.hostname,path:location.pathname,hosts,selector:selectorPath(el)};
  }
  function applyExceptions() {
    for(const el of restored) own(el,RESTORE,()=>el.removeAttribute(RESTORE));
    restored.clear();
    for(const entry of settings.exceptions) {
      if(entry.path!==location.pathname || entry.hostname!==location.hostname) continue;
      try {
        let root=document;
        for(const host of entry.hosts) {root=shadow(root.querySelector(host));if(!root)break;}
        if(!root)continue;
        for(const el of root.querySelectorAll(entry.selector)) {own(el,RESTORE,()=>el.setAttribute(RESTORE,''));restored.add(el);unhide(el);}
      } catch {}
    }
  }
  function playerFor(video) {
    let scope=video.parentElement || video.getRootNode().host;
    for(let n=scope,depth=0;n && depth<4;depth++,n=parent(n)) {
      if(n===document.body || n.matches('main, article, header') || n.querySelector('h1') || n.querySelectorAll('video').length>1) break;
      scope=n;
    }
    if(scope)players.set(video,scope);
  }
  function labelNode(el) {
    if(el.closest('h1,h2,h3,h4,h5,h6,blockquote,pre,code,q') || el.querySelector('h1,h2,h3,h4,h5,h6'))return false;
    const aria=el.getAttribute('aria-label');if(aria && aria.length<=80 && api.label(aria))return true;
    if(el.childElementCount>4 || el.childNodes.length>8)return false;
    const text=el.textContent || '';
    return text.length<=80 && api.label(text) || [...el.childNodes].some(n=>n.nodeType===3 && n.nodeValue.length<=80 && api.label(n.nodeValue));
  }
  function safeHeuristic(label) {
    let fallback=null;
    for(let el=label,depth=0;el && depth<8;el=parent(el),depth++) {
      if(protectedElement(el))return fallback;
      // Never ascend from one advertisement into a whole feed or news section.
      if(el.querySelectorAll('article,[role="article"]').length>1)return fallback;
      const links=[...(el.matches('a[href]')?[el]:[]),...el.querySelectorAll('a[href]')];
      if(links.length>40)return fallback;
      const organic=new Set();
      for(const a of links){try{const u=new URL(a.href);if((api.isDzen(u.hostname) || u.origin===location.origin) && /^\/(?:a|b|media|video\/watch|shorts)\//.test(u.pathname))organic.add(u.origin+u.pathname);}catch{}}
      if(organic.size>1)return fallback;
      const adRoute=links.some(a=>api.adLink(a.href));
      const erid=el.hasAttribute('data-erid') || !!el.querySelector('[data-erid],a[href*="erid="]');
      const actions=[...(el.matches('a,button,[role="button"]')?[el]:[]),...el.querySelectorAll('a,button,[role="button"]')];
      const text=n=>(n.getAttribute('aria-label') || n.textContent || '').trim().replace(/\s+/g,' ');
      const strong=actions.some(n=>/^(?:перейти на сайт|открыть сайт|посетить сайт|оставить заявку|узнать цену)$/iu.test(text(n)));
      const more=actions.some(n=>/^подробнее$/iu.test(text(n)));
      if(!adRoute && !erid && !strong && !more)continue;
      const external=links.some(a=>{try{const u=new URL(a.href);return /^https?:$/.test(u.protocol) && !api.isDzen(u.hostname) && u.hostname!==location.hostname && !api.label(text(a));}catch{return false;}});
      const media=[...el.querySelectorAll('img')].some(img=>{const r=img.getBoundingClientRect();return r.width>=100 && r.height>=55;}) || !!el.querySelector('[style*="background-image"][style*="url("]');
      // An ordinary outbound link + the word “Реклама” is insufficient.
      const evidence=adRoute || erid || strong || more && (external || media);
      if(!evidence || organic.size && !adRoute && !erid && !strong && !(more && (external || media)))continue;
      const box=el.getBoundingClientRect();
      if(box.width<100 || box.height<24 || box.width>Math.max(innerWidth*.9,400) || box.height>innerHeight*1.5)continue;
      fallback ||= el;
      if(media || el.matches('article,[role="article"],.card,[data-testid="feed-card"],[data-testid="card"]'))return el;
    }
    return fallback;
  }
  function iframeEvidence(frame) {
    if(!iframeListeners.has(frame)) {iframeListeners.add(frame);frame.addEventListener('load',()=>schedule(frame));}
    try {
      const doc=frame.contentDocument;
      if(!doc?.body || doc.querySelector(api.protectedContent))return;
      const hasLink=[...doc.querySelectorAll('a[href]')].some(a=>api.adLink(a.href));
      if(hasLink && [...doc.querySelectorAll('span,div,small')].some(el=>el.childElementCount===0 && api.label(el.textContent))) hide(frame,'iframe:label-and-ad-link');
    } catch {}
  }
  function* inspect(root) {
    const candidates=[];
    if(root.nodeType===1 && root.matches(combined))candidates.push(root);
    candidates.push(...root.querySelectorAll(combined));
    for(const el of candidates) {
      if(el.matches(api.slots.join(',')))hide(el,'builtin:ad-slot');
      else {const rule=remote.find(r=>el.matches(r.selector));if(rule)hide(el,`filter:${rule.id}`);}
      yield;
    }
    const elements=document.createTreeWalker(root,NodeFilter.SHOW_ELEMENT);
    let el=root.nodeType===1 ? root : elements.nextNode();
    while(el) {
      metrics.scanned++;
      if(!el.matches('script,style,link,meta')) {
        const sr=shadow(el);if(sr)rootAdded(sr);
        if(el.localName==='video')playerFor(el);
        if(el.localName==='iframe')iframeEvidence(el);
        if(settings.heuristics && labelNode(el) && !composedClosest(el,`[${MARK}]`) && visible(el)) {
          const container=safeHeuristic(el);if(container)hide(container,'heuristic:label-and-evidence');
        }
        if(el.matches('[data-testid="browser-switch-trap-close"]') && visible(el))el.click();
      }
      yield;el=elements.nextNode();
    }
  }
  function scopes() {
    const all=[...pending].filter(x=>x===document || x.isConnected);pending.clear();
    return all.filter((root,i)=>!all.some((other,j)=>j!==i && other!==root && other.contains(root)));
  }
  function* work() {
    applyExceptions();
    for(const root of scopes()) {
      for(const el of [...records.keys()]) if(el===root || root.contains(el))unhide(el);
      yield* inspect(root);
    }
    for(const root of roots)ensureStyle(root);
    // Early CSS is only a bridge until guarded, reversible processing is ready.
    document.documentElement?.removeAttribute('data-dzen-clean-early');
    skipAds();
  }
  function enabled() {return settings.enabled && !api.protectedPage(location.href);}
  function flush() {
    timer=undefined;
    if(!enabled() || !settings.cosmetic) {pending.clear();iterator=null;return;}
    const start=performance.now();
    iterator ||= work();
    let done=false,count=0;
    while(performance.now()-start<8 && count++<180) {done=iterator.next().done;if(done)break;}
    metrics.batches++;metrics.maxBatchMs=Math.max(metrics.maxBatchMs,performance.now()-start);
    if(done)iterator=null;
    if(iterator || pending.size)timer=setTimeout(flush,0);
  }
  function schedule(root=document) {
    if(!enabled())return;
    if(root.nodeType===1)root=root.closest(`[${MARK}]`) || root;
    pending.add(root);
    timer ??= setTimeout(flush,50);
  }
  function cleanup() {
    clearTimeout(timer);timer=undefined;iterator=null;pending.clear();
    for(const el of [...records.keys()])unhide(el);
    for(const style of styles.values())style.remove();
    document.documentElement?.removeAttribute('data-dzen-clean-early');
  }
  const observation={subtree:true,childList:true,characterData:true,attributes:true};
  const observer=new MutationObserver(changes=>{
    for(const change of changes) {
      const el=change.target.nodeType===3 ? change.target.parentElement : change.target;
      if(!el || el.nodeType!==1 && el.nodeType!==11 && el.nodeType!==9)continue;
      if(change.type==='attributes') {
        const writes=ownWrites.get(el);
        if(writes?.has(change.attributeName) && writes.get(change.attributeName)===el.getAttribute(change.attributeName))continue;
      }
      if(el.nodeType===1 && el.closest('style[data-dzen-clean-style],script'))continue;
      if(change.type==='childList') {
        if(change.removedNodes.length)schedule(el);
        for(const node of change.addedNodes)if(node.nodeType===1 && !node.matches('style[data-dzen-clean-style]'))schedule(node);
      } else schedule(el.parentElement || el);
    }
    ownWrites.clear();
    checkRoute();
  });
  function rebuildRules(bundle) {
    remote=[];remoteExceptions=[];
    const matchHost=rule=>rule.domains.some(h=>location.hostname===h || location.hostname.endsWith('.'+h)) && !rule.excluded.some(h=>location.hostname===h || location.hostname.endsWith('.'+h));
    for(const rule of bundle?.rules?.cosmetic || []) {
      if(!matchHost(rule))continue;
      try {document.querySelector(rule.selector);(rule.exception ? remoteExceptions : remote).push(rule);}catch{metrics.invalidSelectors++;}
    }
    combined=[...api.slots,...remote.map(r=>r.selector)].join(',');
  }
  function configure(value,bundle) {
    observer.disconnect();cleanup();settings=api.forDzen ? api.forDzen(value,location.hostname) : api.normalize(value);configured=true;
    if(bundle)rebuildRules(bundle);
    applyExceptions();
    if(enabled()) {
      for(const root of roots) {if(settings.cosmetic)ensureStyle(root);observer.observe(root,observation);}
      schedule(document);
      if(!settings.cosmetic)discoverIterator=discover(document);
    }
  }
  function checkRoute() {
    if(location.pathname===lastPath)return;
    lastPath=location.pathname;
    dispatchEvent(new CustomEvent('dzen-clean-route'));
    configure(settings);
  }
  function* discover(root) {
    const walk=document.createTreeWalker(root,NodeFilter.SHOW_ELEMENT);
    for(let el;(el=walk.nextNode());) {
      const sr=shadow(el);if(sr)rootAdded(sr);
      if(el.localName==='video')playerFor(el);
      yield;
    }
  }
  function scanPlayers(scope) {
    const areas=[scope,...[...roots].filter(r=>r.host && contains(scope,r.host))];
    return areas.flatMap(area=>[...area.querySelectorAll('button,[role="button"]')]);
  }
  function skipAds() {
    if(!enabled() || document.hidden)return;
    for(const [video,scope] of players) {
      if(!video.isConnected || !scope.isConnected) {players.delete(video);continue;}
      if(!visible(video))continue;
      for(const button of scanPlayers(scope)) {
        metrics.buttonChecks++;
        const label=button.getAttribute('aria-label') || button.textContent || '';
        const skip=settings.skipVideo && api.skipLabel(label);
        const close=settings.cosmetic && /^Закрыть баннер$/iu.test(label.trim());
        if(!skip && !close || button.matches(':disabled,[disabled],[aria-disabled="true"]') || !visible(button))continue;
        if(Date.now()-(lastClick.get(button)||0)<3000)continue;
        lastClick.set(button,Date.now());button.click();if(skip)metrics.clicks++;else metrics.closed++;
      }
    }
  }
  const interval=setInterval(()=>{
    checkRoute();if(!enabled() || document.hidden)return;
    for(const root of roots)if(root!==document && !root.host.isConnected){roots.delete(root);styles.delete(root);}
    for(const el of [...records.keys()])if(!el.isConnected)records.delete(el);
    skipAds();
  },500);
  const discovery=setInterval(()=>{
    if(!enabled() || document.hidden)return;
    discoverIterator ||= discover(document);
    const step=()=>{if(!enabled()) {discoverIterator=null;return;} const start=performance.now();
      while(discoverIterator && performance.now()-start<6)if(discoverIterator.next().done){discoverIterator=null;break;}
      if(discoverIterator)setTimeout(step,0);
    };step();
  },2000);
  addEventListener('dzen-clean-module',event=>{const d=event.detail;if(d && ['findSsrAd','initAdvManager','rtb','cookies'].includes(d.name) && ['active','stopped','incompatible'].includes(d.state))moduleStates[d.name]=d.state;});
  addEventListener('popstate',checkRoute);
  addEventListener('pagehide',event=>{if(!event.persisted){clearInterval(interval);clearInterval(discovery);observer.disconnect();}});
  function snapshot(details=false) {
    return {kind:api.pageKind(location.pathname),enabled:enabled(),profile:settings.profile,processing:!!iterator || pending.size>0,
      hidden:records.size, clicks:metrics.clicks, closed:metrics.closed,
      capabilities:{closedShadow:typeof chrome.dom?.openOrClosedShadowRoot==='function'}, modules:{...moduleStates},
      performance:{...metrics,maxBatchMs:Math.round(metrics.maxBatchMs*100)/100},
      reasons:[...new Set([...records.values()].map(x=>x.reason))].slice(0,50),
      ...(details ? {blocks:[...records.entries()].slice(0,100).map(([el,r])=>({id:r.id,tag:el.localName,reason:r.reason,mode:r.mode}))} : {})};
  }
  globalThis.__dzenClean02={snapshot};
  chrome.runtime.onMessage.addListener((message,sender,respond)=>{
    if(sender.id!==chrome.runtime.id)return;
    if(message?.type==='stats'){respond(snapshot(true));return;}
    if(message?.type==='restore-block') {
      const found=[...records.entries()].find(([,r])=>r.id===message.id);
      if(!found){respond({ok:false,error:'Блок уже изменился. Обновите список.'});return;}
      try {
        const exception=exceptionFor(found[0]);
        chrome.runtime.sendMessage({type:'add-exception',exception}).then(result=>{if(result?.ok){unhide(found[0]);}respond(result);},()=>respond({ok:false,error:'Не удалось сохранить исключение'}));
      }catch(error){respond({ok:false,error:error.message});}
      return true;
    }
  });
  chrome.storage.onChanged.addListener((changes,area)=>{
    if(area!=='local')return;
    if(changes.settings || changes.filterCache) {
      revision++;
      configure(changes.settings?.newValue || settings,changes.filterCache?.newValue?.active);
    }
  });
  const initial=revision;
  chrome.storage.local.get(['settings','filterCache']).then(data=>{if(revision===initial)configure(data.settings,data.filterCache?.active);}).catch(()=>{if(!configured)configure(api.defaults);});
})();
